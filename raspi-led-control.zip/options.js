
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PIN2 = exports.PIN1 = exports.PORT = void 0;

const PORT = 80;    // HTTP alapértelmezett port
exports.PORT = PORT;

const PIN1 = 32;    // GPIO pin LED1-hez
exports.PIN1 = PIN1;

const PIN2 = 12;    // GPIO pin LED2-höz
exports.PIN2 = PIN2;
