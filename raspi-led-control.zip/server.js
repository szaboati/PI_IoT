
"use strict";
const express = require("express");
const rpio = require("rpio");
const { PORT, PIN1, PIN2 } = require("./options");

const App = express();
App.use(express.json());
App.use(express.static("./www"));

// GPIO inicializálás
rpio.open(PIN1, rpio.OUTPUT, rpio.HIGH); // LED1 alapból BE
rpio.open(PIN2, rpio.OUTPUT, rpio.LOW);  // LED2 alapból KI

// LED1 állapot lekérdezése
App.get("/led1", (req, res) => {
    const led = rpio.read(PIN1);
    res.send(led.toString());
});

// LED1 vezérlés
App.post("/on1", (req, res) => {
    rpio.write(PIN1, rpio.HIGH);
    res.send("ok");
});
App.post("/off1", (req, res) => {
    rpio.write(PIN1, rpio.LOW);
    res.send("ok");
});

// LED2 állapot lekérdezése
App.get("/led2", (req, res) => {
    const led = rpio.read(PIN2);
    res.send(led.toString());
});

// LED2 vezérlés
App.post("/on2", (req, res) => {
    rpio.write(PIN2, rpio.HIGH);
    res.send("ok");
});
App.post("/off2", (req, res) => {
    rpio.write(PIN2, rpio.LOW);
    res.send("ok");
});

// Szerver indítása
App.listen(PORT, () => {
    console.log(`A szolgáltatás aktív az alábbi porton: ${PORT}`);
});
